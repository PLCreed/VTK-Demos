﻿#include <QApplication>
#include <QImage>
#include <QDebug>

#include "spectrogram.h"
#include "rasteritem.h"
#include "interval.h"
#include "colormap.h"
#include "transform.h"
#include "matrixrasterdata.h"


namespace
{
class RasterData : public QwtMatrixRasterData
{
public:
    RasterData()
    {
        const double matrix[] =
        {
            1, 2, 4, 1,
            6, 3, 5, 2,
            4, 2, 1, 5,
            5, 4, 2, 3
        };

        QVector<double> values;
        for (uint i = 0; i < sizeof(matrix) / sizeof(double); i++)
            values += matrix[i];

        const int numColumns = 4;
        setValueMatrix(values, numColumns);

        setInterval(Qt::XAxis,
                    QwtInterval(-0.5, 3.5, QwtInterval::ExcludeMaximum));
        setInterval(Qt::YAxis,
                    QwtInterval(-0.5, 3.5, QwtInterval::ExcludeMaximum));
        setInterval(Qt::ZAxis, QwtInterval(1.0, 6.0));
    }
};


class LinearColorMap : public QwtLinearColorMap
{
public:
    LinearColorMap(int formatType) : QwtLinearColorMap(Qt::darkBlue, Qt::darkRed)
    {
        //        setFormat(( QwtColorMap::Format ) formatType);

        addColorStop(0.2, Qt::blue);
        addColorStop(0.4, Qt::cyan);
        addColorStop(0.6, Qt::yellow);
        addColorStop(0.8, Qt::red);
    }
};

}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);


    RasterData *rasterData = new RasterData();
    rasterData->setResampleMode(QwtMatrixRasterData::ResampleMode::BicubicInterpolation);

    QwtPlotSpectrogram *spectrogram = new QwtPlotSpectrogram();
    spectrogram->setRenderThreadCount(4);   // use system specific thread count
    //    spectrogram->setCachePolicy(QwtPlotRasterItem::PaintCache);
    spectrogram->setData(rasterData);
    spectrogram->setColorMap(new LinearColorMap(QwtColorMap::RGB));
    spectrogram->setAlpha(255);


    QList<double> contourLevels;
    for (double level = 0.5; level < 10.0; level += 1.0)
        contourLevels += level;
    spectrogram->setContourLevels(contourLevels);

    spectrogram->setDisplayMode(QwtPlotSpectrogram::ContourMode, true);
    //    spectrogram->setDisplayMode(QwtPlotSpectrogram::ImageMode, true);
    spectrogram->setDefaultContourPen(true ? QPen(Qt::black, 0) : QPen(Qt::NoPen));

    const QwtInterval xInterval = spectrogram->data()->interval(Qt::XAxis);
    const QwtInterval yInterval = spectrogram->data()->interval(Qt::YAxis);
    const QwtInterval zInterval = spectrogram->data()->interval(Qt::ZAxis);

    QRect rect(QPoint(0, 0), QSize(1000, 1000));

    QwtScaleMap xMap;
    xMap.setScaleInterval(xInterval.minValue(), xInterval.maxValue());
    xMap.setPaintInterval(rect.left(), rect.right());
    QwtScaleMap yMap;
    yMap.setScaleInterval(yInterval.minValue(), yInterval.maxValue());
    yMap.setPaintInterval(rect.bottom(), rect.top());

    QImage image(rect.size(), QImage::Format_ARGB32);
    QPainter p;
    p.begin(&image);

    p.drawRect(rect);
    spectrogram->draw(&p, xMap, yMap, rect);

    p.end();

    image.save("../image.png");

    return 0;
}
